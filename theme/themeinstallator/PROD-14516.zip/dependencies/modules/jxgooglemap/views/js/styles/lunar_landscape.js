if (typeof(google_map_style) == 'undefined') {
  var google_map_style = [];
}
google_map_style['lunar_landscape'] = [{"stylers":[{"hue":"#ff1a00"},{"invert_lightness":true},{"saturation":-100},{"lightness":33},{"gamma":0.5}]},{"featureType":"water","elementType":"geometry","stylers":[{"color":"#2D333C"}]}]