# JX Featured Posts

v 0.0.3
UPD: removed Translator parameter from Repository class in order to reach compatibility with PS 1.7.6.1

v 0.0.2
UPD: implemented a compatibility with JX Blog v 1.1*; added an opportunity to display a categories tree in the admin panel form